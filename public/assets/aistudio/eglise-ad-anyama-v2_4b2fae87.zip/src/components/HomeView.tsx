import React from 'react';
import { Culte, EventItem, NewsItem, AlbumItem, DepartmentItem, PageView } from '../types';
import { HERO_IMAGE, CHURCH_INFO } from '../mockData';
import { SectionHead, Meta, DateBlock, formatDate } from './ui';
import { BookOpen, Clock, MapPin, Play, Share2, ChevronRight, Bell, Images, CalendarDays, Newspaper, Users } from 'lucide-react';

interface HomeViewProps {
  cultes: Culte[];
  events: EventItem[];
  news: NewsItem[];
  albums: AlbumItem[];
  departments: DepartmentItem[];
  onSelectCulte: (culte: Culte) => void;
  onSelectEvent: (event: EventItem) => void;
  onSelectDepartment: (dept: DepartmentItem) => void;
  onSelectNews: (item: NewsItem) => void;
  onSelectAlbum: (album: AlbumItem) => void;
  onNavigate: (page: PageView) => void;
  onOpenNotifications: () => void;
  onOpenShare: (title: string, summary: string, query?: string) => void;
  logoUrl?: string | null;
}

/* Semaine affichée du lundi au dimanche */
const WEEK = [
  { weekday: 1, short: 'Lun' },
  { weekday: 2, short: 'Mar' },
  { weekday: 3, short: 'Mer' },
  { weekday: 4, short: 'Jeu' },
  { weekday: 5, short: 'Ven' },
  { weekday: 6, short: 'Sam' },
  { weekday: 0, short: 'Dim' }
];

/** Prochain rassemblement à partir d’aujourd’hui (calculé depuis les horaires officiels). */
const nextGathering = (today: number) => {
  for (let i = 0; i < 7; i++) {
    const wd = (today + i) % 7;
    const s = CHURCH_INFO.schedules.find((x) => x.weekday === wd);
    if (s) return { ...s, when: i === 0 ? 'Aujourd’hui' : i === 1 ? 'Demain' : s.day };
  }
  return null;
};

export const HomeView: React.FC<HomeViewProps> = ({
  cultes,
  events,
  news,
  albums,
  departments,
  onSelectCulte,
  onSelectEvent,
  onSelectDepartment,
  onSelectNews,
  onSelectAlbum,
  onNavigate,
  onOpenNotifications,
  onOpenShare
}) => {
  const latestCulte = cultes.find((c) => c.status === 'publie') || cultes[0];
  const upcomingEvents = events.slice(0, 3);
  const latestNews = news.slice(0, 3);
  const featuredAlbums = albums.slice(0, 3);
  const today = new Date().getDay();
  const next = nextGathering(today);

  const scrollToSchedule = () => document.getElementById('horaires')?.scrollIntoView({ behavior: 'smooth' });

  return (
    <div>
      {/* 1. Accueil : identité de l’église */}
      <section className="border-b border-church-line bg-white">
        <div className="page grid items-center gap-8 py-6 sm:py-10 lg:grid-cols-[1fr_1.05fr] lg:gap-14 lg:py-14">
          <div className="order-2 lg:order-1">
            <p className="text-[15px] font-medium text-church-blue">
              Église Évangélique des Assemblées de Dieu de Côte d’Ivoire
            </p>
            <h1 className="mt-2 text-[2.4rem] leading-[1.08] sm:text-5xl lg:text-[3.6rem]">
              Assemblées de Dieu d’Anyama
            </h1>
            <p className="mt-2 font-serif text-xl text-church-muted sm:text-2xl">Ran Extension Résidentiel</p>

            <p className="mt-6 max-w-lg text-[17px]">
              Bienvenue. Retrouvez ici les horaires des cultes, les prédications, le programme des événements et la vie
              des départements de l’église.
            </p>

            {next && (
              <button
                onClick={scrollToSchedule}
                className="mt-6 flex w-full max-w-lg items-center gap-4 rounded-lg border border-church-line bg-church-light p-4 text-left hover:border-church-blue"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-church-blue text-white">
                  <Clock className="h-5 w-5" aria-hidden="true" />
                </span>
                <span className="min-w-0">
                  <span className="block text-sm text-church-muted">Prochain rassemblement</span>
                  <span className="block font-semibold text-church-navy">
                    {next.when}, {next.time}
                  </span>
                  <span className="block truncate text-sm">{next.name}</span>
                </span>
              </button>
            )}

            <div className="mt-6 flex flex-wrap gap-3">
              {latestCulte && (
                <button onClick={() => onSelectCulte(latestCulte)} className="btn-primary">
                  <BookOpen className="h-4 w-4" aria-hidden="true" />
                  Écouter la dernière prédication
                </button>
              )}
              <button onClick={() => onNavigate('evenements')} className="btn-secondary">
                Voir l’agenda
              </button>
            </div>
          </div>

          <div className="order-1 -mx-4 sm:mx-0 lg:order-2">
            <img
              src={HERO_IMAGE}
              alt="L’assemblée réunie pendant le culte"
              className="aspect-[16/10] w-full object-cover sm:rounded-lg lg:aspect-[4/3.4]"
            />
          </div>
        </div>
      </section>

      {/* Accès rapides */}
      <nav aria-label="Accès rapides" className="page pt-6 sm:pt-8">
        <ul className="grid grid-cols-3 gap-2 sm:grid-cols-6">
          {[
            { label: 'Horaires', icon: Clock, action: scrollToSchedule },
            { label: 'Prédications', icon: BookOpen, action: () => onNavigate('cultes') },
            { label: 'Agenda', icon: CalendarDays, action: () => onNavigate('evenements') },
            { label: 'Actualités', icon: Newspaper, action: () => onNavigate('actualites') },
            { label: 'Photos', icon: Images, action: () => onNavigate('galerie') },
            { label: 'Groupes', icon: Users, action: () => onNavigate('departements') }
          ].map(({ label, icon: Icon, action }) => (
            <li key={label}>
              <button
                onClick={action}
                className="surface flex w-full flex-col items-center gap-1.5 px-2 py-3.5 text-sm font-medium text-church-navy hover:border-church-blue"
              >
                <Icon className="h-5 w-5 text-church-blue" aria-hidden="true" />
                {label}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      {/* 2. La semaine à l’église — élément central de la page */}
      <section id="horaires" className="page scroll-mt-20 pt-10 sm:pt-14">
        <SectionHead title="La semaine à l’église" />
        <p className="-mt-2 mb-4 text-sm text-church-muted">
          Les jours en bleu foncé sont les jours de culte. Le jour entouré, c’est aujourd’hui.
        </p>
        <div className="surface overflow-hidden">
          <ol className="grid grid-cols-7 border-b border-church-line" aria-label="Jours de rassemblement">
            {WEEK.map(({ weekday, short }) => {
              const s = CHURCH_INFO.schedules.find((x) => x.weekday === weekday);
              const isToday = weekday === today;
              return (
                <li
                  key={weekday}
                  className={`relative flex min-h-[92px] flex-col items-center justify-start gap-2 border-r border-church-line px-1 pb-3 pt-3 last:border-r-0 sm:min-h-[110px] ${
                    s ? 'bg-church-navy text-white' : 'text-church-muted'
                  }`}
                >
                  <span
                    className={`rounded-full px-2 text-[13px] font-semibold sm:text-sm ${
                      isToday ? (s ? 'bg-white text-church-navy' : 'bg-church-blue text-white') : s ? 'text-white' : ''
                    }`}
                  >
                    {short}
                  </span>
                  {s ? (
                    <span className="whitespace-nowrap text-center font-serif text-[15px] leading-tight sm:text-xl">
                      {s.time.split(' – ')[0].replace(' h ', 'h')}
                    </span>
                  ) : (
                    <span className="mt-2 h-px w-4 bg-church-line" aria-hidden="true" />
                  )}
                  {isToday && <span className="sr-only">(aujourd’hui)</span>}
                </li>
              );
            })}
          </ol>

          <ul className="divide-y divide-church-line">
            {CHURCH_INFO.schedules.map((s) => (
              <li key={s.day} className="flex flex-col gap-1 px-4 py-4 sm:flex-row sm:items-baseline sm:gap-6 sm:px-6">
                <span className="w-56 shrink-0 font-semibold text-church-navy">
                  {s.day}, {s.time}
                </span>
                <span>{s.name}</span>
              </li>
            ))}
          </ul>

          <div className="flex flex-col gap-3 border-t border-church-line bg-church-light px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <span className="flex items-center gap-2 text-sm text-church-muted">
              <MapPin className="h-4 w-4 shrink-0 text-church-blue" aria-hidden="true" />
              {CHURCH_INFO.address}
            </span>
            <button onClick={onOpenNotifications} className="btn-secondary self-start sm:self-auto">
              <Bell className="h-4 w-4 text-church-blue" aria-hidden="true" />
              Recevoir un rappel avant le culte
            </button>
          </div>
        </div>
      </section>

      {/* 3. Dernière prédication */}
      {latestCulte && (
        <section className="page pt-12 sm:pt-16">
          <SectionHead title="Dernière prédication" linkLabel="Tous les cultes" onLink={() => onNavigate('cultes')} />
          <article className="surface grid overflow-hidden md:grid-cols-[1fr_1.25fr]">
            <button onClick={() => onSelectCulte(latestCulte)} className="relative block bg-church-navy" aria-label={latestCulte.title}>
              <img src={latestCulte.coverImage} alt="" className="aspect-video h-full w-full object-cover md:aspect-auto" />
              {latestCulte.hasVideo && (
                <span className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 rounded bg-church-navy px-2.5 py-1 text-[13px] font-medium text-white">
                  <Play className="h-3.5 w-3.5 fill-white" aria-hidden="true" /> Vidéo
                  {latestCulte.videoDuration && <span className="text-white/75">{latestCulte.videoDuration}</span>}
                </span>
              )}
            </button>

            <div className="flex flex-col p-5 sm:p-7">
              <Meta
                items={[
                  formatDate(latestCulte.date),
                  latestCulte.preacher && <span className="text-church-dark">{latestCulte.preacher}</span>,
                  latestCulte.isDemo && <span className="demo-tag">Démonstration</span>
                ]}
              />
              <h3 className="mt-3 text-2xl sm:text-[1.7rem]">
                <button onClick={() => onSelectCulte(latestCulte)} className="text-left hover:text-church-blue">
                  {latestCulte.title}
                </button>
              </h3>

              {latestCulte.scriptureRef && (
                <p className="mt-4 border-l-2 border-church-blue pl-4 font-serif text-lg italic text-church-navy">
                  {latestCulte.scriptureRef}
                </p>
              )}

              {latestCulte.sermonSummary && (
                <p className="mt-4 line-clamp-3 text-church-dark">{latestCulte.sermonSummary}</p>
              )}

              <div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-6">
                <button onClick={() => onSelectCulte(latestCulte)} className="btn-primary">
                  Lire la prédication
                </button>
                <button
                  onClick={() => onOpenShare(latestCulte.title, latestCulte.sermonSummary, `page=culte&id=${latestCulte.id}`)}
                  className="btn-ghost"
                >
                  <Share2 className="h-4 w-4" aria-hidden="true" /> Partager
                </button>
              </div>
            </div>
          </article>
        </section>
      )}

      {/* 4. Événements et actualités côte à côte sur grand écran */}
      <div className="page grid grid-cols-1 gap-12 pt-12 sm:pt-16 lg:grid-cols-2 lg:gap-10">
        <section className="min-w-0">
          <SectionHead title="Prochains événements" linkLabel="L’agenda" onLink={() => onNavigate('evenements')} />
          {upcomingEvents.length === 0 ? (
            <p className="text-church-muted">Aucun événement annoncé pour le moment.</p>
          ) : (
            <ul className="surface divide-y divide-church-line">
              {upcomingEvents.map((ev) => (
                <li key={ev.id}>
                  <button
                    onClick={() => onSelectEvent(ev)}
                    className="flex w-full items-center gap-4 p-4 text-left hover:bg-church-light"
                  >
                    <DateBlock date={ev.date} />
                    <span className="min-w-0 flex-1">
                      <span className="block font-semibold leading-snug text-church-navy">{ev.title}</span>
                      <span className="mt-1 block truncate text-sm text-church-muted">
                        {[ev.time, ev.location].filter(Boolean).join(', ')}
                      </span>
                    </span>
                    <ChevronRight className="h-5 w-5 shrink-0 text-church-muted" aria-hidden="true" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="min-w-0">
          <SectionHead title="Actualités" linkLabel="Toutes les actualités" onLink={() => onNavigate('actualites')} />
          {latestNews.length === 0 ? (
            <p className="text-church-muted">Aucune actualité publiée pour le moment.</p>
          ) : (
            <ul className="surface divide-y divide-church-line">
              {latestNews.map((n) => (
                <li key={n.id}>
                  <button onClick={() => onSelectNews(n)} className="block w-full p-4 text-left hover:bg-church-light">
                    <span className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                      <span className={n.category === 'Communiqué officiel' ? 'font-semibold text-church-blue' : 'text-church-muted'}>
                        {n.category}
                      </span>
                      <span className="text-church-muted">{formatDate(n.date)}</span>
                      {n.isUrgent && <span className="font-semibold text-[#B42318]">Important</span>}
                    </span>
                    <span className="mt-1 block font-semibold leading-snug text-church-navy">{n.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* 5. Galerie */}
      {featuredAlbums.length > 0 && (
        <section className="page pt-12 sm:pt-16">
          <SectionHead title="En images" linkLabel="Toute la galerie" onLink={() => onNavigate('galerie')} />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {featuredAlbums.map((alb) => (
              <button key={alb.id} onClick={() => onSelectAlbum(alb)} className="group text-left">
                <span className="relative block overflow-hidden rounded-lg bg-church-navy">
                  <img src={alb.coverImage} alt="" className="aspect-[4/3] w-full object-cover transition-opacity group-hover:opacity-90" />
                  <span className="absolute bottom-2 left-2 inline-flex items-center gap-1 rounded bg-white px-2 py-0.5 text-[13px] font-medium text-church-navy">
                    <Images className="h-3.5 w-3.5" aria-hidden="true" /> {alb.mediaCount}
                  </span>
                </span>
                <span className="mt-2 block font-semibold leading-snug text-church-navy group-hover:text-church-blue">
                  {alb.title}
                </span>
                <span className="block text-sm text-church-muted">{formatDate(alb.date)}</span>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* 6. Départements */}
      <section className="page pt-12 sm:pt-16">
        <SectionHead title="Départements et groupes" linkLabel="Tous les départements" onLink={() => onNavigate('departements')} />
        <ul className="flex flex-wrap gap-2">
          {departments.map((d) => (
            <li key={d.id}>
              <button onClick={() => onSelectDepartment(d)} className="chip">
                {d.name}
              </button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};
