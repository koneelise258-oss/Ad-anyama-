import React from 'react';
import { NewsItem } from '../types';
import { Share2 } from 'lucide-react';
import { BackBar, formatDate } from './ui';

interface NewsDetailPageProps {
  newsItem: NewsItem;
  onBack: () => void;
  onOpenShare: (title: string, summary: string) => void;
}

export const NewsDetailPage: React.FC<NewsDetailPageProps> = ({ newsItem, onBack, onOpenShare }) => {
  const official = newsItem.category === 'Communiqué officiel';
  const share = () => onOpenShare(newsItem.title, newsItem.summary);

  return (
    <div>
      <BackBar backLabel="Actualités" onBack={onBack} onShare={share} />

      <article className="page max-w-3xl py-6 sm:py-10">
        <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
          <span className={official ? 'font-semibold text-church-blue' : 'text-church-muted'}>{newsItem.category}</span>
          <span className="text-church-muted">{formatDate(newsItem.date)}</span>
          {newsItem.isUrgent && <span className="font-semibold text-[#B42318]">Important</span>}
          {newsItem.isDemo && <span className="demo-tag">Démonstration</span>}
        </p>
        <h1 className="mt-2 text-[2rem] leading-tight sm:text-[2.6rem]">{newsItem.title}</h1>

        {(newsItem.author || newsItem.authorRole) && (
          <p className="mt-4 border-b border-church-line pb-4 text-[15px] text-church-muted">
            Publié par <span className="font-semibold text-church-navy">{newsItem.author}</span>
            {newsItem.authorRole && <>, {newsItem.authorRole}</>}
          </p>
        )}

        {newsItem.coverImage && (
          <img src={newsItem.coverImage} alt="" className="-mx-4 mt-6 w-[calc(100%+2rem)] max-w-none object-cover sm:mx-0 sm:w-full sm:rounded-lg" />
        )}

        {newsItem.summary && <p className="mt-6 font-serif text-xl leading-relaxed text-church-navy">{newsItem.summary}</p>}
        {newsItem.fullContent && <div className="mt-5 whitespace-pre-line text-[17px] leading-relaxed">{newsItem.fullContent}</div>}

        <div className="mt-10 border-t border-church-line pt-6">
          <button onClick={share} className="btn-secondary">
            <Share2 className="h-4 w-4 text-church-blue" aria-hidden="true" /> Partager cette information
          </button>
        </div>
      </article>
    </div>
  );
};
