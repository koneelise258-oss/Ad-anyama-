import React from 'react';
import { EventItem } from '../types';
import { Clock, MapPin, User, CalendarPlus, Check } from 'lucide-react';
import { BackBar, BlockTitle, DateBlock, useToast } from './ui';
import { canAddEventToCalendar, downloadEvent } from '../calendar';

interface EventDetailPageProps {
  event: EventItem;
  onBack: () => void;
  onToggleRegister: (eventId: string) => void;
  onOpenShare: (title: string, summary: string) => void;
}

export const EventDetailPage: React.FC<EventDetailPageProps> = ({ event, onBack, onToggleRegister, onOpenShare }) => {
  const toast = useToast();
  const canCalendar = canAddEventToCalendar(event.date, event.time);

  const toggle = () => {
    onToggleRegister(event.id);
    toast.show(event.isRegistered ? 'Participation retirée' : 'Participation enregistrée');
  };

  return (
    <div>
      <BackBar backLabel="Événements" onBack={onBack} onShare={() => onOpenShare(event.title, event.description)} />

      <div className="page max-w-3xl py-6 sm:py-10">
        <div className="flex items-start gap-4">
          <DateBlock date={event.date} className="mt-1" />
          <div className="min-w-0">
            <p className="text-sm">
              <span className="font-medium text-church-blue">{event.category}</span>
              {event.isDemo && <span className="demo-tag ml-2">Démonstration</span>}
            </p>
            <h1 className="mt-1 text-[2rem] leading-tight sm:text-[2.5rem]">{event.title}</h1>
          </div>
        </div>

        <img src={event.coverImage} alt="" className="-mx-4 mt-6 aspect-[16/9] w-[calc(100%+2rem)] max-w-none object-cover sm:mx-0 sm:w-full sm:rounded-lg" />

        {/* Informations pratiques */}
        <dl className="surface mt-6 divide-y divide-church-line">
          <div className="flex gap-3 p-4">
            <Clock className="mt-0.5 h-5 w-5 shrink-0 text-church-blue" aria-hidden="true" />
            <div>
              <dt className="text-sm text-church-muted">Quand</dt>
              <dd className="font-semibold text-church-navy">{event.date}</dd>
              {event.time && <dd>{event.time}</dd>}
            </div>
          </div>
          {event.location && (
            <div className="flex gap-3 p-4">
              <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-church-blue" aria-hidden="true" />
              <div>
                <dt className="text-sm text-church-muted">Où</dt>
                <dd className="font-semibold text-church-navy">{event.location}</dd>
              </div>
            </div>
          )}
          {event.speaker && (
            <div className="flex gap-3 p-4">
              <User className="mt-0.5 h-5 w-5 shrink-0 text-church-blue" aria-hidden="true" />
              <div>
                <dt className="text-sm text-church-muted">Intervenants</dt>
                <dd className="font-semibold text-church-navy">{event.speaker}</dd>
              </div>
            </div>
          )}
        </dl>

        {/* Actions principales */}
        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <button
            onClick={toggle}
            aria-pressed={!!event.isRegistered}
            className={event.isRegistered ? 'btn-secondary flex-1 border-church-blue text-church-blue' : 'btn-primary flex-1'}
          >
            {event.isRegistered ? (
              <>
                <Check className="h-4 w-4" aria-hidden="true" /> Je participe (annuler)
              </>
            ) : (
              'Je participe'
            )}
          </button>
          {canCalendar && (
            <button
              onClick={() => {
                if (downloadEvent(event)) toast.show('Ouvrez le fichier pour l’ajouter à votre agenda');
              }}
              className="btn-secondary flex-1"
            >
              <CalendarPlus className="h-4 w-4 text-church-blue" aria-hidden="true" /> Ajouter à mon agenda
            </button>
          )}
        </div>
        {event.attendeesCount > 0 && (
          <p className="mt-2 text-sm text-church-muted">{event.attendeesCount} personnes ont indiqué leur participation.</p>
        )}

        {event.description && (
          <section className="mt-10">
            <BlockTitle>Programme</BlockTitle>
            <p className="whitespace-pre-line text-[17px] leading-relaxed">{event.description}</p>
          </section>
        )}
      </div>

      {toast.node}
    </div>
  );
};
